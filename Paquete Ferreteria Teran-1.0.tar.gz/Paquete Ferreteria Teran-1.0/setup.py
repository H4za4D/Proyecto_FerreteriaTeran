from setuptools import setup

setup(
    name = "Paquete Ferreteria Teran",
    version="1.0",
    description="Paquete que contiene todos los modulos necesarios para el programa ",
    author = "Luis Muñoz",
    author_email="llll@gmail.com",
    packages=["Main","Main.Imagenes","Main.Inicializador","Main.LOGIN","Main.PRINCIPAL","Main.TOOLS"]
)