import sys

for x in sys.path:
   print(x)
   
