import datetime as dt
import logging
import math
# PyQt5 import Qt
import random
import threading
import time

from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QTableWidgetItem

from Main.TOOLS.Tools import Crud_DB, MessageBX

logging.basicConfig(level=logging.DEBUG, format="[%(threadName)-s] %(message)s")


class Sell:
    def __init__(self, mainWiU, tb_product, btnagregarP,
                 btnmodificarP, btnlimpiarP, btneliminarV, btnconfirmarV,
                 btncancelarV, btnbuscarCli, btnproductoV,
                 ln_buscarCli, ln_dn, ln_direccion,
                 ln_codPro, ln_descrip, ln_stock, ln_precio, ln_cantidad,
                 ln_subtotal, ln_igv, ln_total, lbl_canastaContador, lbl_usuarioActual):

        self.__searcher = Crud_DB()
        self.__dialogo = MessageBX()

        self.mainWindowCli = mainWiU

        self.tb_product = tb_product

        # self.tb_product.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)  # Se estable la politica del men
        # self.tb_product.customContextMenuRequested.connect(
        # self.menuAccion)  # Al presionar anticlick este llamara al menu

        # Botones
        self.btnagregarP = btnagregarP
        self.btnmodificarP = btnmodificarP
        self.btnlimpiarP = btnlimpiarP
        self.btneliminarV = btneliminarV
        self.btnconfirmarV = btnconfirmarV
        self.btncancelarV = btncancelarV
        self.btnbuscarCli = btnbuscarCli
        self.btnproductoV = btnproductoV

        self.tb_product.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)  # Se estable la politica del men
        self.tb_product.customContextMenuRequested.connect(
            self.menuAccionProducto)

        """Conexion con los funciones respectivas de cada boton"""

        self.btnagregarP.clicked.connect(self.addProduct)
        self.btnmodificarP.clicked.connect(self.modifyProduct)
        self.btnlimpiarP.clicked.connect(self.cleanAll)
        self.btneliminarV.clicked.connect(self.deleteProduct)
        self.btnconfirmarV.clicked.connect(self.confirmVent)
        self.btncancelarV.clicked.connect(self.cancelVent)
        self.btnbuscarCli.clicked.connect(self.searchCli)
        self.btnproductoV.clicked.connect(self.searchProd)

        self.ln_buscarCli = ln_buscarCli
        self.ln_dn = ln_dn
        self.ln_direccion = ln_direccion
        self.ln_codPro = ln_codPro
        self.ln_descrip = ln_descrip
        self.ln_stock = ln_stock
        self.ln_precio = ln_precio
        self.ln_cantidad = ln_cantidad
        self.ln_subtotal = ln_subtotal
        self.ln_igv = ln_igv
        self.ln_total = ln_total

        self.lbl_canastaContador = lbl_canastaContador
        self.lbl_usuarioActual = lbl_usuarioActual

        self.__list_LineEditWidgets = [self.ln_dn, self.ln_direccion,
                                       self.ln_descrip, self.ln_stock, self.ln_precio,
                                       self.ln_subtotal, self.ln_subtotal, self.ln_total, self.ln_igv]

        self.__ROWCOUNTER = 0
        self.__TOTAL_PAGAR = 0
        self.__SELECTED_ROW = 0  # Guardara el indice de la fila seleccionada

        self.enabled_LineEdits(True)

    def enabled_LineEdits(self, bool):
        for wi in self.__list_LineEditWidgets:
            wi.setReadOnly(bool)

    def addProduct(self):

        """Con esta funcion se puede agregar productos a la lista del pedido siempre y cuando ya se haya buscado un producto
                a agregar , a la par este calculara el total, subtotal e igv del pedido"""
        if self.ln_codPro.text() == "":
            self.__dialogo.setTxt("Aviso", "No haz buscado un producto")
            self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
            self.__dialogo.exec_()
        else:
            if self.ln_cantidad.text() == "":
                self.__dialogo.setTxt("Aviso", f"No haz ingresado la cantidad a pedir")
                self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                self.__dialogo.exec_()
            else:
                if self.ln_cantidad.text().isalpha():
                    self.__dialogo.setTxt("Aviso", f"Dato invalido en \'Cantidad\'")
                    self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                    self.__dialogo.exec_()

                else:
                    if self.tb_product.findItems(self.ln_codPro.text(), Qt.MatchExactly):
                        self.__dialogo.setTxt("Aviso", f"Producto ya ingresado")
                        self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                        self.__dialogo.exec_()

                    else:
                        self.tb_product.setRowCount(self.__ROWCOUNTER + 1)
                        self.tb_product.setItem(self.__ROWCOUNTER, 0, QTableWidgetItem(self.ln_codPro.text()))
                        self.tb_product.setItem(self.__ROWCOUNTER, 1, QTableWidgetItem(self.ln_descrip.text()))
                        self.tb_product.setItem(self.__ROWCOUNTER, 2, QTableWidgetItem(self.ln_cantidad.text()))
                        self.tb_product.setItem(self.__ROWCOUNTER, 3, QTableWidgetItem(str(self.ln_precio.text())))

                        self.__ROWCOUNTER += 1

                        self.__TOTAL_PAGAR += round(float(self.ln_cantidad.text()) * float(self.ln_precio.text()), 2)
                        igv = math.floor(self.__TOTAL_PAGAR * 0.18)
                        print(igv)
                        semi = self.__TOTAL_PAGAR - igv
                        print(semi)

                        self.ln_subtotal.setText(str(semi))
                        self.ln_igv.setText(str(igv))
                        self.ln_total.setText(str(self.__TOTAL_PAGAR))

                        self.lbl_canastaContador.setText(str(self.__ROWCOUNTER))

                        self.ln_codPro.clear()
                        self.ln_descrip.clear()
                        self.ln_stock.clear()
                        self.ln_precio.clear()
                        self.ln_cantidad.clear()

    def modifyProduct(self):

        self.enabled_LineEdits(True)
        self.ln_cantidad.setReadOnly(False)

        if self.ln_stock.text() == "":
            self.__dialogo.setTxt("Aviso", "No haz escogido un Producto a modificar ")
            self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
            self.__dialogo.exec_()

        else:
            self.tb_product.setItem(self.__SELECTED_ROW, 2, QTableWidgetItem(self.ln_cantidad.text()))
            self.enabled_LineEdits(False)
            self.__SELECTED_ROW = 0  # RESTABLESCO EL VALOR

            """Se hace de nuevo el calculo con la nueva cantidad"""
            item = self.allDataFromTable()

            self.__TOTAL_PAGAR = 0
            igv = 0
            semi = 0

            for data in item:
                print(data)
                self.__TOTAL_PAGAR += round(float(data[2]) * float(data[3]), 2)
                igv = round(self.__TOTAL_PAGAR * 0.18, 2)
                print(igv)
                semi = self.__TOTAL_PAGAR - igv
                print(semi)

            self.ln_subtotal.setText(str(semi))
            self.ln_igv.setText(str(igv))
            self.ln_total.setText(str(self.__TOTAL_PAGAR))

    def cleanAll(self):
        self.__SELECTED_ROW = 0
        self.tb_product.clearContents()
        self.__ROWCOUNTER = 0
        self.__TOTAL_PAGAR = 0

        for x in self.__list_LineEditWidgets:
            x.clear()

        self.lbl_canastaContador.setText("0")



    def deleteProduct(self):
        self.tb_product.removeRow(self.tb_product.currentRow())
        self.btnmodificarP.setEnabled(True)
        self.btneliminarV.setEnabled(True)
        self.btnlimpiarP.setEnabled(True)
        self.btnagregarP.setEnabled(True)
        self.btnconfirmarV.setEnabled(True)


    def allDataFromTable(self):
        item = []
        rows = self.tb_product.rowCount()
        for n in range(rows):
            fila = []
            for column in range(4):
                r = self.tb_product.item(n, column)
                fila.append(r.text())
            item.append(fila)

        print(item)

        return item

    def confirmVent(self):
        if not self.ln_buscarCli.text() == "":

            """Se obtiene una lista de todos los items de la lista """
            item = self.allDataFromTable()

            C_pedido = 'PTR' + str(random.randint(1000, 9999))
            # fecha = dt.datetime.now().strftime("%Y/%B/%d-%H:%M:%S")
            fecha = str(dt.datetime.now().strftime("%d/%m/%Y %H:%M:%S"))

            try:

                result = None

                codEmpleado = self.__searcher.runQuery("SELECT CodEmpleado FROM DetallesUsuarios WHERE Usuario = ?",
                                                       (self.lbl_usuarioActual.text(),),
                                                       select=True)

                if self.registerClientePedido(C_pedido, str(codEmpleado[0][0]), fecha):

                    for product in item:
                        result = self.__searcher.runQuery("INSERT INTO [Detalles de Pedido] VALUES(?,?,?)", (C_pedido,
                                                                                                             product[0],
                                                                                                             product[2]
                                                                                                             ))

                    if result:

                        confirm = QMessageBox().information(None, "Nota", "¿Procede a registrar el pedido?",
                                                            QMessageBox.Yes | QMessageBox.No)

                        if confirm == QMessageBox.Yes:
                            self.__dialogo.setTxt("Exito", "Pedido Guardado con exito ")
                            self.__dialogo.insertIcon("Imagenes/accept.ico", QMessageBox.Information)
                            self.__dialogo.exec_()

                            self.__dialogo.setTxt("Nota",
                                                  f"Codigo de pedido:\n---> {C_pedido} <---\nPendiente de cobro")
                            self.__dialogo.insertIcon("Imagenes/accept.ico", QMessageBox.Warning)
                            self.__dialogo.exec_()

                            self.cleanAll()


            except Exception as e:
                self.__dialogo.setTxt("Aviso", f"error: {type(e).__name__}zzz{e.__str__()}")
                self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                self.__dialogo.exec_()

        else:
            self.__dialogo.setTxt("Error", f"Campo DNI vacio")
            self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Critical)
            self.__dialogo.exec_()

    def cancelVent(self):
        pass

    def searchCli(self):
        self.dni = self.ln_buscarCli.text()

        query = "SELECT Nombre, Direccion FROM Cliente WHERE Dni = ? "
        prmt = (self.dni,)

        if not self.dni == "":
            if str(self.dni).isnumeric():
                rs = self.__searcher.runQuery(query=query, parameters=prmt, select=True)

                if rs:

                    self.ln_dn.setText(rs[0][0])
                    self.ln_direccion.setText(str(rs[0][1]).replace("_", " "))

                else:
                    confir = QMessageBox().warning(None, "Cliente no encontrado",
                                                   "¿Quieres ingresar un usuario Corriente?",
                                                   QMessageBox.Yes | QMessageBox.No)
                    self.ln_dn.clear()
                    self.ln_direccion.clear()

                    self.ln_dn.setReadOnly(True)

                    if confir == QMessageBox.Yes:
                        self.ln_descrip.setReadOnly(True)

                        r = QMessageBox().information(None, "Nota", "Ingresa un número de DNI", QMessageBox.Ok)

            else:
                QMessageBox().critical(None, "Error", "Dni solo es numérico",
                                       QMessageBox.Ok)

        else:
            QMessageBox().critical(None, "Error", "Campo dni vacio",
                                   QMessageBox.Ok)

    def searchProd(self):
        self.codToSearch = self.ln_codPro.text()

        query = "SELECT Descripcion, Stock, Precio FROM Producto WHERE CodProducto = ? "
        prmt = (self.codToSearch,)

        rs = self.__searcher.runQuery(query, parameters=prmt, select=True)

        if rs:
            self.ln_descrip.setText(str(rs[0][0]))
            self.ln_stock.setText(str(rs[0][1]))
            self.ln_precio.setText(str(rs[0][2]))
        else:
            self.__dialogo.setTxt("Aviso", "Producto No encontrado")
            self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
            self.__dialogo.exec_()

    def registerClientePedido(self, cod, empleado, fecha):
        logging.info("Hilo insertar dni temporal")
        self.estado = 2
        ok = False

        if self.ln_dn.text() == "":  # Evaluo que lel nombre del cliente este vacio asi podre registratlo
            if str(self.ln_buscarCli.text()).isnumeric():
                if len(self.ln_buscarCli.text()) == 8:

                    try:
                        """Es ta pieza de codigo es reduntante lo cual se puede mejorar """
                        prmt = (self.ln_buscarCli.text(), "-", "-", "-", "-", "-")
                        resul = self.__searcher.runQuery("INSERT INTO Cliente VALUES(?,?,?,?,?,?);",
                                                         parameters=prmt)
                        if resul:
                            print("Cliente insertado")

                        time.sleep(1)

                        prmtped = (
                            cod, self.ln_total.text(), 0, 0, self.estado, self.ln_buscarCli.text(), empleado, fecha)

                        resulped = self.__searcher.runQuery("INSERT INTO Pedido VALUES(?,?,?,?,?,?,?,?);",
                                                            parameters=prmtped)
                        ok = True

                    except Exception as e:
                        self.__dialogo.setTxt("Aviso", f"error: {type(e).__name__}xx{e.__str__()}")
                        self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                        self.__dialogo.exec_()

                else:
                    self.__dialogo.setTxt("Aviso", "El campo Dni no tiene 8 digitos")
                    self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                    self.__dialogo.exec_()

            else:
                self.__dialogo.setTxt("Aviso", "El campo Dni no es numerico")
                self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                self.__dialogo.exec_()

        else:
            try:
                prmtped = (cod, self.ln_total.text(), 0, 0, self.estado, self.ln_buscarCli.text(), empleado, fecha)
                resulped = self.__searcher.runQuery("INSERT INTO Pedido VALUES(?,?,?,?,?,?,?,?)", parameters=prmtped)
                ok = True

            except Exception as e:
                self.__dialogo.setTxt("Aviso", f"error: {type(e).__name__}----{e.__str__()}")
                self.__dialogo.insertIcon("Imagenes/cancel.ico", QMessageBox.Warning)
                self.__dialogo.exec_()

        return ok

    def menuAccionProducto(self, posicition):
        self.menu = QtWidgets.QMenu()

        itemsGroup = QtWidgets.QActionGroup(self.mainWindowCli)
        itemsGroup.setExclusive(True)

        self.menu.addAction(QtWidgets.QAction("Seleccionar Fila", itemsGroup))

        itemsGroup.triggered.connect(self.selectProductoToModify)
        self.menu.exec_(self.tb_product.viewport().mapToGlobal(posicition))

    def selectProductoToModify(self):

        self.__SELECTED_ROW = self.tb_product.currentRow()

        itm = []
        for item in self.tb_product.selectedItems():  # Con for se recorre la fila seleccionada
            itm.append(item.text())  # Se agraga cada item pero convirtiendolo a un string

        stock = self.__searcher.runQuery("SELECT Stock FROM Producto WHERE CodProducto = ? ", (itm[0]), select=True)[0][
            0]

        self.ln_codPro.setText(itm[0])
        self.ln_descrip.setText(itm[1])
        self.ln_cantidad.setText(itm[2])
        self.ln_stock.setText(str(stock))
        self.ln_precio.setText(itm[3])
